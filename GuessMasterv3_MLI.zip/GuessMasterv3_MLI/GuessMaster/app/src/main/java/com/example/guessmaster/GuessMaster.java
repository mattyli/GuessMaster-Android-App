package com.example.guessmaster;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.widget.*;
import android.view.View.OnClickListener;
import android.view.View;

import java.util.Random;

/*
    NOTES:
    - I did not create a continueGame() method for when the user enters the wrong date
      as all you need to do is clear the input and keep the game running
    - In the future, will need to add a try-catch block to catch the error that causes the
      game to crash when they enter an invalid date, or could be implemented with a helper method
      did not have time to complete that.

 */


// Assignment 3 - Matthew Li (20217346) April 7th 2022
public class GuessMaster extends AppCompatActivity {
    // SETUP & VARIABLE DECLARATION
    // ANDROID VARIABLES
    private TextView entityName;
    private TextView ticketSum;
    private Button guessButton;
    private Button clearButton;
    private EditText userIn;
    private ImageView entityImage;
    String answer;

    // GAME VARIABLES
    private int numOfEntities;                      // store the number of entities
    private Entity[] entities;                      // list to store the entities
    int currentTicketWon = 0;                       // store the current # of tickets won
    private int numOfTickets = 0;                       // store the number of tickets
    String entName;                                 // store the entity name
    int entityId = 0;                               // hold the entity ID
    private Entity currentEnt;                      // hold the current entity being played

    // ANDROID LOGIC - written by Matthew Li
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);                                 // Use the super constructor
        setContentView(R.layout.activity_guess_activity);                   // Use the lay specified within the activity_guess_activity.xml
        guessButton = (Button)this.findViewById(R.id.btnGuess);                // creating the guessButton and linking it by ID
        clearButton = (Button)this.findViewById(R.id.btnClear);                // ^ same as above
        userIn      = (EditText)this.findViewById(R.id.guessInput);             // Getting the user input
        ticketSum   = (TextView)this.findViewById(R.id.ticket);                 // To update the number of tickets (Top RHS)
        entityImage = (ImageView)this.findViewById(R.id.entityImage);
        entityName  = (TextView)this.findViewById(R.id.entityName);
        //  intializing the game variables & initial actions here
        Politician jTrudeau = new Politician("Justin Trudeau", new Date("December", 25, 1971), "Male", "Liberal", 0.25);
        Singer cDion        = new Singer("Celine Dion", new Date("March", 30, 1961), "Female", "La voix du bon Dieu", new Date("November", 6, 1981), 0.5);
        Person myCreator    = new Person("My Creator", new Date("September", 1, 2000),"Female", 1);
        Country usa         = new Country("United States", new Date("July", 4, 1776), "Washinton D.C.", 0.1);
        Person cokeMan      = new Person("Coke Man", new Date("September", 4, 2002), "Male", 2);

        new GuessMaster();           // class constructor

        addEntity(jTrudeau);         // Adding entities to the game
        addEntity(cDion);
        addEntity(myCreator);
        addEntity(usa);
        addEntity(cokeMan);

        changeEntity();                     // make a new random entity, first one to be played
        welcomeToGame(currentEnt);          // display the welcome alert

        // In app lifetime, onCreate is only executed once, buttons essentially act as loops when they are pressed

        // onClick listener for clearButton
        clearButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                changeEntity();             // change the entity to something random
            }
        });

        guessButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                playGame(currentEnt);       // start playing the game with the current ent
            }
        });

    }// onCreate()

    public void changeEntity(){
        if(!userIn.getText().toString().isEmpty()){     // if there was something entered
            userIn.getText().clear();                   // clear previous entry
        }
        entityId = genRandomEntityId();                 // make the new ID
        Entity tempEnt  = entities[entityId];           // set the current entity to the selected one
        currentEnt = tempEnt;                           // probably not necessary
        entName = currentEnt.getName();
        entityName.setText(entName);                    // set the entityName to current entity name
        ImageSetter();                                  // need the name to get the correct image
    }

    // Helper function for whenever the image needs to be changed.
    public void ImageSetter(){
        switch (currentEnt.getName()){//getName returns a string
            case "Justin Trudeau":
                entityImage.setImageResource(R.drawable.justint);
                break;
            case "Celine Dion":
                entityImage.setImageResource(R.drawable.celidion);
                break;
            case "My Creator":
                entityImage.setImageResource(R.drawable.creator);
                break;
            case "Coke Man":
                entityImage.setImageResource(R.drawable.cokedout);
                break;
            case "United States":
                entityImage.setImageResource(R.drawable.usaflag);
                break;
        }
    }// makes use of global variable currentEnt

    public void welcomeToGame(Entity entity){
        AlertDialog.Builder welcomeAlert = new AlertDialog.Builder(GuessMaster.this);
        welcomeAlert.setTitle("GuessMaster Game V3");
        welcomeAlert.setMessage(entity.welcomeMessage());
        welcomeAlert.setCancelable(false);                  // there is no cancel button
        welcomeAlert.setNegativeButton("START_GAME", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Toast.makeText(getBaseContext(), "Game is Starting... Enjoy", Toast.LENGTH_SHORT).show();
            }
        });
        welcomeAlert.show();
    }

    // GAME LOGIC - written by the ELEC 279 course team
    public GuessMaster() {
        numOfEntities = 0;
        entities = new Entity[10];
    }

    public void addEntity(Entity entity){
        entities[numOfEntities++] = entity.clone();
    }

    // Written by Matthew Li
    public void playGame(Entity entity) {
        entityName.setText(entity.getName());               // setting the entity name in the textview
        answer = userIn.getText().toString();               // get user input, convert to string
        answer = answer.replace("\n","").replace("\r","");      // string should have slashes
        Date answerDate = new Date(answer);                 // making new date object with answer for comparison

        // CHECKING USER INPUT
        if (answerDate.precedes(entity.getBorn())){
            // try a later date
            AlertDialog.Builder laterAlert = new AlertDialog.Builder(GuessMaster.this);
            laterAlert.setTitle("Incorrect");
            laterAlert.setIcon(R.drawable.ic_error_outline_black_24dp);         // display the error image
            laterAlert.setMessage("Try a later date");
            laterAlert.setCancelable(false);                  // there is no cancel button
            laterAlert.setNegativeButton("Ok", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    // let the round keep playing, delete the old input
                    userIn.getText().clear();
                }
            });
            // Show the dialog
            AlertDialog dialog = laterAlert.create();
            dialog.show();
        }
        else if (entity.getBorn().precedes(answerDate)){
            // try an earlier date
            AlertDialog.Builder earlyAlert = new AlertDialog.Builder(GuessMaster.this);
            earlyAlert.setTitle("Incorrect");
            earlyAlert.setIcon(R.drawable.ic_error_outline_black_24dp);
            earlyAlert.setMessage("Try an earlier date");
            earlyAlert.setCancelable(false);                  // there is no cancel button
            earlyAlert.setNegativeButton("Ok", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    // let the round keep playing, clear the user input
                    userIn.getText().clear();
                }
            });
            AlertDialog dialog = earlyAlert.create();
            dialog.show();                              // showing the dialog
        }
        else{
            // the guess is correct
            // increase the number of tickets, and write that value to the textview (tickets)
            currentTicketWon = entity.getAwardedTicketNumber();                     // get the number of tickets won this round
            numOfTickets += currentTicketWon;                                       // incrementing the total number of tickets won
            ticketSum.setText("Tickets: " + Integer.toString(numOfTickets));        // updating the number of tickets
            AlertDialog.Builder wonAlert = new AlertDialog.Builder(GuessMaster.this);
            wonAlert.setTitle("Winner!");
            wonAlert.setMessage("Congratulations! The information is: \n" + entity.toString());
            wonAlert.setCancelable(false);                  // there is no cancel button
            wonAlert.setNegativeButton("Ok", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    // change the entity
                    changeEntity();
                }
            });
            AlertDialog dialog = wonAlert.create();
            dialog.show();
        }
    }

    public int genRandomEntityId() {
        Random randomNumber = new Random();
        return randomNumber.nextInt(numOfEntities);
    }
}