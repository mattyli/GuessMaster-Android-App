package com.example.guessmaster;

public class WrongDateFormat extends Exception{
    // exception for when the wrong date is entered in GM
    public WrongDateFormat(){
        super();
    }
}
